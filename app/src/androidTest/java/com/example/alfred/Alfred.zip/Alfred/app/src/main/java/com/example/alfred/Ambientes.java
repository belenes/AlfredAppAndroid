package com.example.alfred;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;



public class Ambientes extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ambientes);

        final EditText ip = findViewById(R.id.ip);
        final ImageButton btnLuz = findViewById(R.id.btnLuz);


    }


}
